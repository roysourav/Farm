
      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Anything you want
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2015 <a href="#">Company</a>.</strong> All rights reserved.
      </footer>

    
    </div><!-- ./wrapper -->

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
     <?php echo Html::script('assets/js/jquery.min.js'); ?>


    <!-- Bootstrap 3.3.5 -->
    <?php echo Html::script('assets/js/bootstrap.min.js'); ?>


    <!-- Date Picker -->

    <?php echo Html::script('assets/js/datepicker.js'); ?>


     <!-- parsley form validation -->
    
    <?php echo Html::script('assets/js/parsley.min.js'); ?>


    <!-- custom js -->
    <?php echo Html::script('assets/js/custom.js'); ?>


    <!-- AdminLTE App -->
    <?php echo Html::script('assets/js/app.min.js'); ?>

   
  </body>

</body>

</html>
