
@include( 'partials._header' )

@include( 'partials._sidebar' )
<!-- Main content -->
   <section class="content">

            @yield('content')

 </section><!-- /.content -->
        

</div><!-- /.content-wrapper -->
    

 @include( 'partials._footer' )


